
/*
 * GET home page.
 */

exports.index = function(req, res){
res.end("Health check!!!");
	
  //res.render('index', { title: 'Express' });
};